#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// Mouse input variables
bool firstMouse = true;
float lastX = 400.0f;
float lastY = 300.0f;
float yaw = -90.0f;
float pitch = 0.0f;
float cameraSpeed = 0.001f;
float cameraRotationSpeed = 0.001f;

// Mouse callback function
void mouse_callback(GLFWwindow* window, double xpos, double ypos) {
    if (firstMouse) {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos; // Reversed because y-coordinates range from bottom to top
    lastX = xpos;
    lastY = ypos;

    const float sensitivity = 0.1f;
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    pitch += yoffset;

    // Clamp pitch to avoid flipping the camera
    if (pitch > 89.0f) pitch = 89.0f;
    if (pitch < -89.0f) pitch = -89.0f;
}

// Scroll callback function
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
    cameraSpeed += yoffset * 0.01f;

    // Ensure the camera speed doesn't go below a minimum value
    if (cameraSpeed < 0.01f) cameraSpeed = 0.01f;
}

// Load Texture function
GLuint textureID;


void loadTexture(const char* texturePath) {
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // Set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    // Set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Load and generate the texture
    int width, height, nrChannels;
    unsigned char* data = stbi_load(texturePath, &width, &height, &nrChannels, 0);
    if (data) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else {
        std::cerr << "Failed to load texture" << std::endl;
    }
    stbi_image_free(data);
}

int main() {
    // Initialize GLFW
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }

    // Create a GLFW window
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(800, 600, "Simple 3D Tree", nullptr, nullptr);
    if (!window) {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);

    // Initialize GLEW
    if (glewInit() != GLEW_OK) {
        std::cerr << "Failed to initialize GLEW" << std::endl;
        glfwTerminate();
        return -1;
    }

    // Vertex shader source code
    const char* vertexShaderSource = R"(
    #version 330 core
    layout(location = 0) in vec3 aPos;
    layout(location = 1) in vec3 aColor;
    layout(location = 2) in vec2 TexCoord; // Added texture coordinates
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;
    out vec3 FragColor;
    out vec2 TexCoordOut; // Pass texture coordinates to fragment shader
    void main()
    {
        gl_Position = projection * view * model * vec4(aPos, 1.0);
        FragColor = aColor;
        TexCoordOut = TexCoord;
    }
)";

    // Fragment shader source code
    const char* fragmentShaderSource = R"(
    #version 330 core
    in vec3 FragColor;
    in vec2 TexCoordOut; // Received texture coordinates
    out vec4 finalColor;
    uniform sampler2D ourTexture; // Texture sampler
    void main()
    {
        // Apply texture to the existing shapes
        vec4 texColor = texture(ourTexture, TexCoordOut) * vec4(FragColor, 1.0);

        // Add a small white circle light in the top right corner
        vec2 lightPos = vec2(0.1, 0.9); // 
        float lightRadius = 0.3; // 
        vec2 diff = lightPos - TexCoordOut;
        float distance = length(diff);

        vec3 lightColor = vec3(1.0, 1.0, 1.0); // White light
        float intensity = smoothstep(1.0 - lightRadius, 1.0, 1.0 - distance);

        finalColor = mix(texColor, vec4(lightColor, 1.0), intensity);
    }
)";






    // Compile and link shaders
    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, nullptr);
    glCompileShader(vertexShader);

    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, nullptr);
    glCompileShader(fragmentShader);

    GLuint shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);

    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    // Define the vertices of the tree and rectangle
    GLfloat vertices[] = {
        // Tree
        // Green Pyramid
    -0.5f, 0.0f, -0.5f, 0.0f, 0.6f, 0.0f, 0.0f, 0.0f, // Bottom triangle
    0.0f, 1.0f, 0.0f, 0.0f, 0.6f, 0.0f, 0.0f, 1.0f,
    0.5f, 0.0f, -0.5f, 0.0f, 0.6f, 0.0f, 1.0f, 0.0f,
    -0.2f, 0.0f, -0.2f, 0.0f, 0.6f, 0.0f, 0.0f, 0.0f, // Left branch
    0.0f, 2.0f, 0.0f, 0.0f, 0.6f, 0.0f, 0.0f, 1.0f,
    -0.2f, 0.0f, 0.2f, 0.0f, 0.6f, 0.0f, 1.0f, 0.0f, // Right branch
    0.2f, 0.0f, -0.2f, 0.0f, 0.6f, 0.0f, 0.0f, 0.0f,
    0.0f, 2.0f, 0.0f, 0.0f, 0.6f, 0.0f, 0.0f, 1.0f,
    0.2f, 0.0f, 0.2f, 0.0f, 0.6f, 0.0f, 1.0f, 0.0f,
    // Brown rectangle
    -1.5f, -2.0f, -1.5f, 0.5f, 0.25f, 0.0f, 0.0f, 0.0f,
    1.5f, -2.0f, -1.5f, 0.5f, 0.25f, 0.0f, 1.0f, 0.0f,
    -1.5f, -2.0f, 1.5f, 0.5f, 0.25f, 0.0f, 0.0f, 1.0f,
    1.5f, -2.0f, -1.5f, 0.5f, 0.25f, 0.0f, 1.0f, 0.0f,
    1.5f, -2.0f, 1.5f, 0.5f, 0.25f, 0.0f, 1.0f, 1.0f,
    -1.5f, -2.0f, 1.5f, 0.5f, 0.25f, 0.0f, 0.0f, 1.0f

    };

    GLuint VAO, VBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // Configure vertex attributes
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (void*)(6 * sizeof(GLfloat)));
    glEnableVertexAttribArray(2);

    // Set up model, view, and projection matrices
    glm::mat4 model = glm::mat4(1.0f);
    glm::mat4 view = glm::lookAt(glm::vec3(0.0f, 2.0f, 4.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 projection = glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 10.0f);

    GLuint modelLoc = glGetUniformLocation(shaderProgram, "model");
    GLuint viewLoc = glGetUniformLocation(shaderProgram, "view");
    GLuint projectionLoc = glGetUniformLocation(shaderProgram, "projection");

    glUseProgram(shaderProgram);

    // Enable depth testing
    glEnable(GL_DEPTH_TEST);

    // Camera parameters
    glm::vec3 cameraPosition = glm::vec3(0.0f, 2.0f, 4.0f);
    glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
    glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

    // Load the texture
    loadTexture("C:/Users/anton/source/repos/Milestone3-5/textures-wood.jpg");


    // Rendering loop
    while (!glfwWindowShouldClose(window)) {
        // Clear the screen and depth buffer
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Handle camera movement
        if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
            cameraPosition += cameraSpeed * cameraFront;
        }
        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
            cameraPosition -= cameraSpeed * cameraFront;
        }
        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
            cameraPosition -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
        }
        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
            cameraPosition += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
        }
        if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {
            cameraPosition -= cameraSpeed * cameraUp;
        }
        if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
            cameraPosition += cameraSpeed * cameraUp;
        }

        // Calculate the new view matrix
        view = glm::lookAt(cameraPosition, cameraPosition + cameraFront, cameraUp);
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));

        // Set transformation matrices for the tree
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Draw the tree with texture
        glBindVertexArray(VAO);
        glDrawArrays(GL_TRIANGLES, 0, 18); // 18 vertices for tree

        // Set transformation matrices for the brown rectangle
        glm::mat4 brownRectModel = glm::mat4(1.0f);
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(brownRectModel));

        // Draw the brown rectangle with texture
        glDrawArrays(GL_TRIANGLES, 18, 6); // 6 vertices for brown rectangle

        // Check and call events
        glfwPollEvents();
        glfwSwapBuffers(window);
    }

    // Cleanup
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteProgram(shaderProgram);

    // Terminate GLFW
    glfwTerminate();

    return 0;
}


